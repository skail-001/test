from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator

class Product(models.Model):
    name = models.CharField(max_length=255)
    slug = models.CharField(max_length=255)
    description = models.TextField()
    image = models.ImageField(upload_to='', default=None, null=True, blank=True, editable=True)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    rating = models.FloatField(validators=[MinValueValidator(0.0), MaxValueValidator(5.0)])
    weight = models.DecimalField(max_digits=10, decimal_places=2)
    publication_time = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
    
    @classmethod
    def get_recent_products(cls, count=3):
        return cls.objects.order_by('-publication_time')[:count]
    
