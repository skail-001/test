from django.shortcuts import render, get_object_or_404
from .models import Product
from django.views import View
from django.shortcuts import redirect
from django.http import HttpResponse

def index(request):
    recent_products = Product.get_recent_products(count=3)
    return render(request, 'index.html', {'recent_products': recent_products})

def about(request):
    return render(request, 'about.html', {})

def panier(request):
    return render(request, 'cart.html', {})

def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug)
    return render(request, 'product_detail.html', {'product': product})
